Instructions:
1) Project is run by using following command:
	BusinessAnalyzer Registered_Business_Locations_-_San_Francisco.csv AL/LL

It is according to requirement
1st argument is CSV File Name.
2nd argument is List Type.

2) Before running first of all remove " from CSV file. By opening file and press Ctrl+A and replace " with blank().

What I Did:
1) I made a BusinessAnalyzer Class in which I made 8 methods including main function.
2) I also made Business Class which is used to store all data from CSV file in variables.
3) I made constructor in Business Class in which variables initialize with data of CSV file.
4) I also made getter and setter methods of all variables in Business Class.
5) In BusinessAnalyzer Class, I made Reading_Data method which is used to read all data from CSV File and make 
Business Class Object and pass data row by row to constructor and that object in List<Business>.
6) Then I made getNaicsCodeRange Method in which naicsCode Argument is passed. I iterate all business objects and call getNAICS_Code from Business 
class and check split that code in start and end range and then I convert start,end, and naicsCode into Integer and 
using If condition i check that in which range it lies. Then return that range in string.
7) Then, I made Executing_User_Commands method. In which I handle all commands from user. And made relevant function
according to commands and call that funtion using If condition.
8) I made printCommandHistory method in which i print all commands entered by user which is added in Queue after
entering each command.
9) And In main method, I made 2 variables fileName and listType and check listType (AA/LL) then call Reading_Data and 
Executing_User_Commands.
