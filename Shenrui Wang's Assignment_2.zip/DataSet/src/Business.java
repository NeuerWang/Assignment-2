public class Business {

//    Instance Variable
    private String Location_Id;
    private String Business_Account_Number;
    private String Ownership_Name;
    private String DBA_Name;
    private String Street_Address;
    private String City;
    private String State;
    private String Source_Zip;
    private String Business_Start_Date;
    private String Business_End_Date;
    private String Location_Start_Date;
    private String Location_End_Date;
    private String Mail_Address;
    private String Mail_City;
    private String Mail_ZipCode;
    private String Mail_State;
    private String NAICS_Code;
    private String NAICS_Code_Description;
    private String Parkng_Tax;
    private String Transient_Occupancy_Tax;
    private String LIC_Code;
    private String LIC_Code_Description;
    private String Supervisor_District;
    private String Neighborhoods_Analysis_Boundaries;
    private String Business_Corridor;
    private String Business_Location;
    private String UniqueID;
    private String SF_Find_Neighborhoods;
    private String Current_Police_Districts;
    private String Current_Supervisor_Districts;
    private String Analysis_Neighborhoods;
    private String Neighborhoods;

//  Constructor which stores each column in given variables
    public Business(String[] data) {
        this.Location_Id = data[0];
        this.Business_Account_Number = data[1];
        this.Ownership_Name = data[2];
        this.DBA_Name = data[3];
        this.Street_Address = data[4];
        this.City = data[5];
        this.State = data[6];
        this.Source_Zip = data[7];
        this.Business_Start_Date = data[8];
        this.Business_End_Date = data[9];
        this.Location_Start_Date = data[10];
        this.Location_End_Date = data[11];
        this.Mail_Address = data[12];
        this.Mail_City = data[13];
        this.Mail_ZipCode = data[14];
        this.Mail_State = data[15];
        this.NAICS_Code = data[16];
        this.NAICS_Code_Description = data[17];
        this.Parkng_Tax = data[18];
        this.Transient_Occupancy_Tax = data[19];
        this.LIC_Code = data[20];
        this.LIC_Code_Description = data[21];
        this.Supervisor_District = data[22];
        this.Neighborhoods_Analysis_Boundaries = data[23];
        this.Business_Corridor = data[24];
        this.Business_Location = data[25];
        this.UniqueID = data[26];
        this.SF_Find_Neighborhoods = data[27];
        this.Current_Police_Districts = data[28];
        this.Current_Supervisor_Districts = data[29];
        this.Analysis_Neighborhoods = data[30];
        this.Neighborhoods = data[31];
    }


    public String getLocation_Id() {
        return Location_Id;
    }

    public void setLocation_Id(String location_Id) {
        Location_Id = location_Id;
    }

    public String getBusiness_Account_Number() {
        return Business_Account_Number;
    }

    public void setBusiness_Account_Number(String business_Account_Number) {
        Business_Account_Number = business_Account_Number;
    }

    public String getOwnership_Name() {
        return Ownership_Name;
    }

    public void setOwnership_Name(String ownership_Name) {
        Ownership_Name = ownership_Name;
    }

    public String getDBA_Name() {
        return DBA_Name;
    }

    public void setDBA_Name(String DBA_Name) {
        this.DBA_Name = DBA_Name;
    }

    public String getStreet_Address() {
        return Street_Address;
    }

    public void setStreet_Address(String street_Address) {
        Street_Address = street_Address;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getSource_Zip() {
        return Source_Zip;
    }

    public void setSource_Zip(String source_Zip) {
        Source_Zip = source_Zip;
    }

    public String getBusiness_Start_Date() {
        return Business_Start_Date;
    }

    public void setBusiness_Start_Date(String business_Start_Date) {
        Business_Start_Date = business_Start_Date;
    }

    public String getBusiness_End_Date() {
        return Business_End_Date;
    }

    public void setBusiness_End_Date(String business_End_Date) {
        Business_End_Date = business_End_Date;
    }

    public String getLocation_Start_Date() {
        return Location_Start_Date;
    }

    public void setLocation_Start_Date(String location_Start_Date) {
        Location_Start_Date = location_Start_Date;
    }

    public String getLocation_End_Date() {
        return Location_End_Date;
    }

    public void setLocation_End_Date(String location_End_Date) {
        Location_End_Date = location_End_Date;
    }

    public String getMail_Address() {
        return Mail_Address;
    }

    public void setMail_Address(String mail_Address) {
        Mail_Address = mail_Address;
    }

    public String getMail_City() {
        return Mail_City;
    }

    public void setMail_City(String mail_City) {
        Mail_City = mail_City;
    }

    public String getMail_ZipCode() {
        return Mail_ZipCode;
    }

    public void setMail_ZipCode(String mail_ZipCode) {
        Mail_ZipCode = mail_ZipCode;
    }

    public String getMail_State() {
        return Mail_State;
    }

    public void setMail_State(String mail_State) {
        Mail_State = mail_State;
    }

    public String getNAICS_Code() {
        return NAICS_Code;
    }

    public void setNAICS_Code(String NAICS_Code) {
        this.NAICS_Code = NAICS_Code;
    }

    public String getNAICS_Code_Description() {
        return NAICS_Code_Description;
    }

    public void setNAICS_Code_Description(String NAICS_Code_Description) {
        this.NAICS_Code_Description = NAICS_Code_Description;
    }

    public String getParkng_Tax() {
        return Parkng_Tax;
    }

    public void setParkng_Tax(String parkng_Tax) {
        Parkng_Tax = parkng_Tax;
    }

    public String getTransient_Occupancy_Tax() {
        return Transient_Occupancy_Tax;
    }

    public void setTransient_Occupancy_Tax(String transient_Occupancy_Tax) {
        Transient_Occupancy_Tax = transient_Occupancy_Tax;
    }

    public String getLIC_Code() {
        return LIC_Code;
    }

    public void setLIC_Code(String LIC_Code) {
        this.LIC_Code = LIC_Code;
    }

    public String getLIC_Code_Description() {
        return LIC_Code_Description;
    }

    public void setLIC_Code_Description(String LIC_Code_Description) {
        this.LIC_Code_Description = LIC_Code_Description;
    }

    public String getSupervisor_District() {
        return Supervisor_District;
    }

    public void setSupervisor_District(String supervisor_District) {
        Supervisor_District = supervisor_District;
    }

    public String getNeighborhoods_Analysis_Boundaries() {
        return Neighborhoods_Analysis_Boundaries;
    }

    public void setNeighborhoods_Analysis_Boundaries(String neighborhoods_Analysis_Boundaries) {
        Neighborhoods_Analysis_Boundaries = neighborhoods_Analysis_Boundaries;
    }

    public String getBusiness_Corridor() {
        return Business_Corridor;
    }

    public void setBusiness_Corridor(String business_Corridor) {
        Business_Corridor = business_Corridor;
    }

    public String getBusiness_Location() {
        return Business_Location;
    }

    public void setBusiness_Location(String business_Location) {
        Business_Location = business_Location;
    }

    public String getUniqueID() {
        return UniqueID;
    }

    public void setUniqueID(String uniqueID) {
        UniqueID = uniqueID;
    }

    public String getSF_Find_Neighborhoods() {
        return SF_Find_Neighborhoods;
    }

    public void setSF_Find_Neighborhoods(String SF_Find_Neighborhoods) {
        this.SF_Find_Neighborhoods = SF_Find_Neighborhoods;
    }

    public String getCurrent_Police_Districts() {
        return Current_Police_Districts;
    }

    public void setCurrent_Police_Districts(String current_Police_Districts) {
        Current_Police_Districts = current_Police_Districts;
    }

    public String getCurrent_Supervisor_Districts() {
        return Current_Supervisor_Districts;
    }

    public void setCurrent_Supervisor_Districts(String current_Supervisor_Districts) {
        Current_Supervisor_Districts = current_Supervisor_Districts;
    }

    public String getAnalysis_Neighborhoods() {
        return Analysis_Neighborhoods;
    }

    public void setAnalysis_Neighborhoods(String analysis_Neighborhoods) {
        Analysis_Neighborhoods = analysis_Neighborhoods;
    }

    public String getNeighborhoods() {
        return Neighborhoods;
    }

    public void setNeighborhoods(String neighborhoods) {
        Neighborhoods = neighborhoods;
    }

}
