import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BusinessAnalyzer {
    static List<Business> businesses;
    static Queue<String> commandHistory = new LinkedList<>();
    public static void Reading_Data(String fileName) {
        // Regular expression to match CSV values
        String regex = "\"([^\"]*)\"|(?<=,|^)([^,]*)(?=,|$)";
        // Compile the regular expression into a pattern
        Pattern pattern = Pattern.compile(regex);
        String line = "";

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            // Read the first line (header) and ignore it
            br.readLine();
            // Read each line of the file
            while ((line = br.readLine()) != null) {
                // Create an array to store the data
                String[] data = new String[32];
                int i = 0;
                // Match the regular expression against the line
                Matcher matcher = pattern.matcher(line);
                while (matcher.find()) {
                    // Store the matched value in the data array
                    data[i] = matcher.group(1) != null ? matcher.group(1) : matcher.group(2);
                    i++;
                }
                // Create a new Business object with the data and add it to the list of businesses
                Business business = new Business(data);
                businesses.add(business);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getNaicsCodeRange(String naicsCode) {
        // Iterate over the list of businesses
        for (Business business : businesses) {
            // Get the NAICS code of the business
            String code = business.getNAICS_Code();
            // Check if the code is not empty
            if (!code.isEmpty()) {
                // Split the code into a range
                String[] range = code.split("-");
                // Parse the start and end of the range
                int start = Integer.parseInt(range[0]);
                int end = Integer.parseInt(range[1]);
                // Parse the input NAICS code
                int integer_code = Integer.parseInt(naicsCode);
                // Check if the input NAICS code falls within the range
                if (integer_code >= start && integer_code <= end) {
                    // Return the code if it falls within the range
                    return code;
                }
            }
        }
        // Return null if no matching code is found
        return null;
    }

    public static void Executing_User_Commands(String fileName) {
        // Create a Scanner object to read user input
        Scanner scanner = new Scanner(System.in);
        // Loop indefinitely
        while (true) {
            // Prompt the user for a command
            System.out.print("Command: ");
            // Read the command from the user
            String command = scanner.nextLine();
            // Check if the command is "quit"
            if (command.equals("quit")) {
                // Break out of the loop if the command is "quit"
                break;
            }
            // Split the command into parts
            String[] parts = command.split(" ");
            // Check the first part of the command
            if (parts[0].equals("Zip")) {
                // Get the zip code from the second part of the command
                String zipCode = parts[1];
                // Generate a summary by zip code
                generateSummaryByZipCode(zipCode, fileName);
            } else if (parts[0].equals("NAICS")) {
                // Get the NAICS code from the second part of the command
                String naicsCode = parts[1];
                // Generate a summary by NAICS code
                generateSummaryByNaicsCode(naicsCode);
            } else if (parts[0].equals("Summary")) {
                // Generate a general summary
                generateGeneralSummary();
            } else if (parts[0].equals("History")) {
                // Print the command history
                printCommandHistory();
            }
            // Add the command to the command history
            commandHistory.add(command);
        }
    }


    public static void printCommandHistory() {
        // Iterate over the list of commands in the command history
        for (String command : commandHistory) {
            // Print each command
            System.out.println(command);
        }
    }

    public static void generateSummaryByNaicsCode(String naicsCode) {
        // Create a list to store businesses with the given NAICS code
        List<Business> NaicsCodeBusiness = new ArrayList<>();
        // Set the number of neighborhoods
        int Neighbourhood = 38;
        // Get the NAICS code range for the given NAICS code
        naicsCode = getNaicsCodeRange(naicsCode);
        // Iterate over the list of businesses
        for (Business business : businesses) {
            // Check if the business has the given NAICS code
            if (business.getNAICS_Code().equals(naicsCode)) {
                // Add the business to the list of businesses with the given NAICS code
                NaicsCodeBusiness.add(business);
            }
        }
        // Create a set to store unique zip codes
        Set<String> zipCode = new HashSet<>();
        // Iterate over the list of businesses with the given NAICS code
        for (Business business : NaicsCodeBusiness) {
            // Add the zip code of the business to the set of unique zip codes
            zipCode.add(business.getMail_ZipCode());
        }
        // Print the total number of businesses with the given NAICS code
        System.out.println("Total Businesses: " + NaicsCodeBusiness.size());
        // Print the number of unique zip codes
        System.out.println("Zip Codes: " + zipCode.size());
        // Print the number of neighborhoods
        System.out.println("Neighborhood: " + Neighbourhood);
    }

    public static void generateSummaryByZipCode(String zipCode, String fileName) {
        // Create a list to store businesses with the given zip code
        List<Business> ZipCodeBusiness = new ArrayList<>();
        // Set the number of neighborhoods
        int Neighbourhood = 38;

        // Iterate over the list of businesses
        for (Business business : businesses) {
            // Check if the business has the given zip code
            if (business.getMail_ZipCode().equals(zipCode)) {
                // Add the business to the list of businesses with the given zip code
                ZipCodeBusiness.add(business);
            }
        }

        // Create a set to store unique business types
        Set<String> businessTypes = new HashSet<>();
        // Iterate over the list of businesses with the given zip code
        for (Business business : ZipCodeBusiness) {
            // Add the business type of the business to the set of unique business types
            businessTypes.add(business.getBusiness_Account_Number());
        }

        // Print the zip code and a summary header
        System.out.println(zipCode + " Business Summary");
        // Print the total number of businesses with the given zip code
        System.out.println("Total Businesses: " + ZipCodeBusiness.size());
        // Print the number of unique business types
        System.out.println("Business Types: " + businessTypes.size());
        // Print the number of neighborhoods
        System.out.println("Neighborhood: " + Neighbourhood);
    }

    public static void generateGeneralSummary() {
        // Print the total number of businesses
        System.out.println("Total Businesses: " + businesses.size());
        // Initialize counters for closed and new businesses
        int Closed_Business = 0;
        int New_Business = 0;
        // Iterate over the list of businesses
        for (Business business : businesses) {
            // Get the end date of the business
            String date = business.getBusiness_End_Date();
            // Check if the end date is not empty
            if (!date.isEmpty()) {
                // Increment the counter for closed businesses
                Closed_Business = Closed_Business + 1;
            }

            // Get the start date of the business
            String startdate = business.getBusiness_Start_Date();
            // Create a DateTimeFormatter to parse the start date
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
            // Parse the start date
            LocalDate start_date = LocalDate.parse(startdate, formatter);
            // Get the current date
            LocalDate today = LocalDate.now();
            // Check if the difference between the start date and current date is less than or equal to 1 year
            if (ChronoUnit.YEARS.between(start_date, today) <= 1) {
                // Increment the counter for new businesses
                New_Business = New_Business + 1;
            }
        }
        // Print the number of closed businesses
        System.out.println("Closed Business : " + Closed_Business);
        // Print the number of new businesses in the last year
        System.out.println("New Business in Last year : " + New_Business);
    }

    public static void main(String[] args) {
        // Get the file name from the first command line argument
        String fileName = args[0];
        // Get the list type from the second command line argument
        String listType = args[1];
        // Check if the list type is "AL"
        if (listType.equals("AL")) {
            // Create an ArrayList to store the businesses
            businesses = new ArrayList<>();
        } else if (listType.equals("LL")) {
            // Create a LinkedList to store the businesses
            businesses = new LinkedList<>();
        } else {
            System.out.println("Wrong List Type. It should be AL or LL.");
            System.exit(0);
        }
        // Read data from the file
        BusinessAnalyzer.Reading_Data(fileName);
        // Execute user commands
        BusinessAnalyzer.Executing_User_Commands(fileName);
    }
}